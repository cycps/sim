# RyMPI
MPI for people who like muffins
