% MEX binding of KINSOL functions
%
%-- Radu Serban @ LLNL -- April 2005
